import pandas as pd
import matplotlib.pyplot as plt

class ProcessarDados:
    def __init__(self, url):
        self.url = url
        self.df = None
        self.df_limpo = None
        
    def carregar_dados(self):
        self.df = pd.read_csv(self.url, delimiter=',')
        self.df.to_csv('base_bruta_covid_usa.csv', sep=';', index=False)
        
    def mostrar_dados(self):
        print(self.df)
        print(self.df.shape)
        print(self.df.info())
        print(self.df.head())
        
    def limpar_dados(self):
        self.df_limpo = self.df.dropna()
        self.df_limpo = self.df_limpo.drop_duplicates()
        self.df_limpo['date'] = pd.to_datetime(self.df_limpo['date'])
        print('Dados Limpos: Valores nulos removidos e duplicatas excluídas.')
        
    def agrupar_por_colunas(self, colunas, agregados):
        return self.df_limpo.groupby(colunas)[agregados].sum().reset_index()
    
    def salvar_dados(self, df, nome_arquivo):
        df.to_csv(nome_arquivo, sep=';', index=False)
        

class VisualizadorDados:
    def plot_top_states(self, df, column, top_n=10, title=""):
        """Gera um gráfico de barras dos estados com mais casos/mortes."""
        top_states = df.sort_values(by=column, ascending=False).head(top_n)
        top_states.plot(kind='bar', x='state', y=column)
        plt.title(title)
        plt.show(block=True)
        
def main():
    url = 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-states.csv'
    processo = ProcessarDados(url)
    
    processo.carregar_dados()
    # processor.mostrar_dados()
    processo.limpar_dados()
    
    total_por_estado = processo.agrupar_por_colunas(['state'], ['cases', 'deaths'])
    total_por_fips = processo.agrupar_por_colunas(['fips'], ['cases', 'deaths'])
    total_por_dia = processo.agrupar_por_colunas(['date'], ['cases', 'deaths'])
    
    visualizar = VisualizadorDados()
    visualizar.plot_top_states(total_por_estado, 'cases', 10, 'Top 10 Estados com mais casos')
    visualizar.plot_top_states(total_por_estado, 'deaths', 10, 'Top 10 Estados com mais mortes')
    
    df_ny =processo.df_limpo[processo.df_limpo['state'] == 'New York']
    casos_ny_tempo = processo.agrupar_por_colunas(['date'], ['cases', 'deaths'])
    processo.salvar_dados(casos_ny_tempo, 'casos_ny_tempo.csv')
    
if __name__ == '__main__':
    main()